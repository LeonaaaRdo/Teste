import React, { useState, useEffect } from 'react';
import { Heart } from 'lucide-react';

function App() {
  // Define a data de início do relacionamento: 18 de outubro de 2024
  const startDate = new Date('2024-10-18');
  const [timeElapsed, setTimeElapsed] = useState({
    months: 0,
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Efeito que atualiza o contador a cada segundo
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const difference = now.getTime() - startDate.getTime();

      // Calcula os meses (aproximadamente, considerando mês como 30.44 dias)
      const months = Math.floor(difference / (1000 * 60 * 60 * 24 * 30.44));
      
      // Calcula os dias restantes após contar os meses completos
      const daysInMonths = months * 30.44;
      const remainingDays = Math.floor(difference / (1000 * 60 * 60 * 24) - daysInMonths);
      
      // Calcula as horas, minutos e segundos
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeElapsed({ months, days: remainingDays, hours, minutes, seconds });
    }, 1000);

    // Limpa o intervalo quando o componente é desmontado
    return () => clearInterval(timer);
  }, []);

  return (
    // Container principal com gradiente de fundo rosa
    <div className="min-h-screen bg-gradient-to-b from-pink-100 to-pink-200 flex items-center justify-center p-4">
      {/* Container do conteúdo central */}
      <div className="max-w-2xl w-full space-y-8 text-center">
        {/* Seção da foto com coração */}
        <div className="relative">
          {/* Imagem do casal */}
          <img
            src="https://drive.google.com/uc?export=view&id=1vWcO7dRy0zWPXIdtXJD0qjLPB6S__yMW"
            alt="Couple"
            className="w-full h-[500px] object-cover rounded-2xl shadow-lg"
          />
          {/* Ícone de coração sobreposto à imagem */}
          <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2">
            <Heart className="w-16 h-16 text-red-500 fill-red-500 drop-shadow-lg" />
          </div>
        </div>
        
        {/* Card com o contador */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 shadow-lg mt-12">
          {/* Título e subtítulo */}
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Nosso Amor</h1>
          <p className="text-gray-600 mb-6">Juntos desde 18 de outubro de 2024</p>
          
          {/* Grid com os contadores */}
          <div className="grid grid-cols-5 gap-4">
            {/* Contador de meses */}
            <div className="bg-pink-50 p-3 rounded-lg">
              <div className="text-3xl font-bold text-pink-600">{timeElapsed.months}</div>
              <div className="text-sm text-gray-600">Meses</div>
            </div>
            {/* Contador de dias */}
            <div className="bg-pink-50 p-3 rounded-lg">
              <div className="text-3xl font-bold text-pink-600">{timeElapsed.days}</div>
              <div className="text-sm text-gray-600">Dias</div>
            </div>
            {/* Contador de horas */}
            <div className="bg-pink-50 p-3 rounded-lg">
              <div className="text-3xl font-bold text-pink-600">{timeElapsed.hours}</div>
              <div className="text-sm text-gray-600">Horas</div>
            </div>
            {/* Contador de minutos */}
            <div className="bg-pink-50 p-3 rounded-lg">
              <div className="text-3xl font-bold text-pink-600">{timeElapsed.minutes}</div>
              <div className="text-sm text-gray-600">Minutos</div>
            </div>
            {/* Contador de segundos */}
            <div className="bg-pink-50 p-3 rounded-lg">
              <div className="text-3xl font-bold text-pink-600">{timeElapsed.seconds}</div>
              <div className="text-sm text-gray-600">Segundos</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;